jQuery(document).ready(function($) {
    $('#cf-select-category').on('change', function() {
        var category = $('#cf-select-category').val();
        $.ajax({
            url: ajax_params.ajax_url,
            type: 'POST',
            data: {
                action: 'fetch_companies',
                category: category,
            },
            success: function(response) {
                $('#cf-post-container').html(response);
            }
        });
    });
	
	$('#company-search').keyup(function() {
        var searchValue = $(this).val();
        if(searchValue) {
            $.ajax({
                type: 'POST',
                url: ajax_params.ajax_url,
                data: { 
                    'action': 'fetch_companies', 
                    'keyword': searchValue 
                },
                success: function(response) {
                    $('#cf-post-container').html(response);
                    return false;
                }
            });
        } else {
            $.ajax({
                type: 'POST',
                url: ajax_params.ajax_url,
                data: { 
                    'action': 'fetch_companies', 
                    'keyword': searchValue 
                },
                success: function(response) {
                    $('#cf-post-container').html(response);
                }
            });
        }
    });
	
	
	
$('#cf-load-more').click(function() {
    var button = $(this),
        spinner = $('.spinner'), // Reference the spinner
        currentPage = parseInt(button.data('page')) + 1,
        data = {
            'action': 'fetch_companies',
            'category': $('#cf-select-category').val(),
            'keyword': $('#company-search').val(),
            'page': currentPage
        };

    // Show spinner and hide button
    spinner.show();

    $.post(ajax_params.ajax_url, data, function(response) {
        // Hide spinner and show button (if there are more items to load)
        spinner.hide();

        // Use jQuery to create a temporary div to hold the response
        var $temp = $("<div>").html(response);

        // If the response contains no .cf-image, assume there are no more items
        if (!$temp.find('.cf-image').length) {
            button.hide(); // Keep the button hidden if no more items
        } else {
            $('#cf-post-container').append(response);
            button.data('page', currentPage).show(); // Update button data-page attribute and show button
        }
    });
});

	
});
