<?php

class Companies_Filter {

    public function __construct() {
		add_action('wp_ajax_fetch_companies', array($this, 'fetch_companies_by_category'));
		add_action('wp_ajax_nopriv_fetch_companies', array($this, 'fetch_companies_by_category'));
		add_shortcode('companies_filter_shortcode', array($this, 'render_companies_filter'));
    }
	
	public function render_companies_filter(){
		ob_start(); 
			?>
			<div class="cf-posts-wrap">
				<div class="cf-filter-content">
					<select id="cf-select-category">
						<option value="">Medical Specialties...</option>
						<?php
						$categories = get_terms('company_category', array('hide_empty' => false));
						foreach ($categories as $category) {
							echo sprintf('<option value="%s">%s</option>', esc_attr($category->term_id), esc_html($category->name));
						}
						?>
					</select>

					<div class="companysearch">
						<input type="text" id="company-search" name="s" placeholder="Search by name or website">
					</div>
				</div>
				
				
				
				<?php
					
			
					$per_page = 3;
					$total_count = 0;
					$args = array(
						'post_type' => 'company',
						'post_status' => 'publish',
						'posts_per_page' => $per_page,
					);
					$query = new wp_query($args);
				?>
				
				<div id="cf-post-container">
					
					<?php
						if ($query->have_posts()) {
							while ($query->have_posts()) {
								$query->the_post();
								$total_count += $total_count;
								echo '<div class="cf-image">';
								$permalink = get_permalink();
								if (has_post_thumbnail()) {
									echo '<a href="' . esc_url($permalink) . '">';
										the_post_thumbnail('full');
										echo '<h3>'.get_the_title().'</h3>';
									echo '</a>';
								}
								
								
								
								echo '</div>';
								
							}
						} else {
							echo 'No posts found.';
						}
						wp_reset_postdata();
					?>
					
					
					

				</div>
				<div id="cf-load-more" data-page="1">Load more <span class="spinner" style="display: none;"></span></div>
				
				
			</div>
			<?php
			return ob_get_clean();  
		}

	
	

	
public function fetch_companies_by_category() {
    $category = isset($_POST['category']) ? intval($_POST['category']) : '';
	$keyword = wp_kses_post($_POST['keyword']);
	$page = isset($_POST['page']) ? intval($_POST['page']) : 1;
	

    $args = [
        'post_type' => 'company',
        'post_status' => 'publish',
        'posts_per_page' => 3, // Adjust according to your needs
        'paged' => $page, // Use the 'paged' parameter for pagination
        'tax_query' => [],
        's' => $keyword,
        'orderby' => 'title',
        'order' => 'ASC',
    ];
	
	
	
	if($category) {
		$args['tax_query'] = array(
			'relation' => 'AND',
			array(
				'taxonomy' => 'company_category',
				'field' => 'term_id',
				'terms' => $category,
				'operator' => 'AND',
			),
		);
	}
	




	

    $query = new WP_Query($args);
	
	if (!empty($letter)) {
        remove_filter('posts_where', 'filter_by_first_letter');
    }

    $html = '';
    if ($query->have_posts()) {
    while ($query->have_posts()) {
        $query->the_post();
        $permalink = get_permalink();
        $post_date = get_the_date(); // If you plan to use $post_date, make sure to include it in the output.

        $html .= '<div class="cf-image">';
        if (has_post_thumbnail() && $permalink) { // Ensure there is a thumbnail and a permalink.
            $html .= '<a href="' . esc_url($permalink) . '">';
            $html .= get_the_post_thumbnail(get_the_ID(), 'full');
			$html .= '<h3>';
			$html .= get_the_title(); // Corrected to use get_the_title().
			$html .= '</h3>';
            $html .= '</a>';
        }

        
        $html .= '</div>';
    }
} else {
        $html = 'No companies found.';
    }

    echo $html;
    wp_reset_postdata();

    wp_die();
}
}

